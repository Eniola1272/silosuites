Silo Suites client design preview

Unzip the archive and upload this folder (the one containing index.html) to Netlify Drop: https://app.netlify.com/drop
No build command or API environment variables are required.
The opening page is Our suites. Open any property to review the updated design.
The Homepage, Hot Springs and Local Guide links open the unchanged live website.
Dates, availability and prices are samples; no reservations, holds or payments are created.
Reviews/ratings are an anonymous public-review snapshot dated 18 November 2026, not a live feed. No guest names, private feedback or API credentials are bundled.
